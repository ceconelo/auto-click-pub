document.addEventListener('DOMContentLoaded', () => {
    const showAlert = (message, isError = false) => {
        const alertDiv = document.createElement('div');
        alertDiv.textContent = message;
        alertDiv.style.position = 'fixed';
        alertDiv.style.bottom = '10px';
        alertDiv.style.left = '50%';
        alertDiv.style.transform = 'translateX(-50%)';
        alertDiv.style.padding = '10px';
        alertDiv.style.borderRadius = '4px';
        alertDiv.style.backgroundColor = isError ? '#f44336' : '#4CAF50';
        alertDiv.style.color = '#fff';
        document.body.appendChild(alertDiv);

        setTimeout(() => {
            alertDiv.remove();
        }, 3000);
    };

    chrome.storage.local.get('interval', (data) => {
        if (data.interval) {
            document.getElementById('interval').value = data.interval / 1000;
        }
    });

    const saveIntervalBtn = document.getElementById('saveIntervalButton');
    const viewSchedulesBtn = document.getElementById('viewSchedulesButton');

    viewSchedulesBtn.onclick = () => {
        chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
            chrome.runtime.sendMessage({type: 'closePopup'});
            chrome.scripting.executeScript({
                target: {tabId: tabs[0].id},
                function: openSchedulesModal
            });
        });
    };

    saveIntervalBtn.onclick = () => {
        const interval = document.getElementById('interval').value;
        const intervalInMs = parseInt(interval) * 1000;

        if (isNaN(intervalInMs) || intervalInMs < 1000) {
            showAlert('Intervalo inválido. Deve ser um número inteiro maior ou igual a 1.', true);
            return;
        }

        chrome.storage.local.set({interval: intervalInMs}, () => {
            showAlert('Intervalo salvo com sucesso!');
        });
    };

    function openSchedulesModal() {
        const modal = document.createElement('div');
        modal.style.position = 'fixed';
        modal.style.zIndex = '1050';
        modal.style.left = '0';
        modal.style.top = '0';
        modal.style.width = '100%';
        modal.style.height = '100%';
        modal.style.overflow = 'auto';
        modal.style.backgroundColor = 'rgb(0,0,0)';
        modal.style.backgroundColor = 'rgba(0,0,0,0.4)';
        modal.style.paddingTop = '60px';

        const modalContent = document.createElement('div');
        modalContent.style.backgroundColor = '#fefefe';
        modalContent.style.margin = '5% auto';
        modalContent.style.padding = '20px';
        modalContent.style.border = '1px solid #888';
        modalContent.style.width = '80%';
        modalContent.style.maxHeight = '80%';
        modalContent.style.overflowY = 'auto';
        modalContent.style.boxShadow = '0 4px 8px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19)';
        modal.appendChild(modalContent);

        const closeBtn = document.createElement('span');
        closeBtn.innerHTML = '&times;';
        closeBtn.style.color = '#aaa';
        closeBtn.style.float = 'right';
        closeBtn.style.fontSize = '28px';
        closeBtn.style.fontWeight = 'bold';
        closeBtn.style.cursor = 'pointer';
        closeBtn.onclick = () => {
            modal.remove();
        };
        modalContent.appendChild(closeBtn);

        const modalTitle = document.createElement('h2');
        modalTitle.textContent = 'Agendamentos';
        modalContent.appendChild(modalTitle);

        const refreshBtn = document.createElement('button');
        refreshBtn.textContent = 'Atualizar';
        refreshBtn.id = 'refreshSchedulesButton';
        refreshBtn.style = 'display: none';
        refreshBtn.onclick = loadSchedules;
        modalContent.appendChild(refreshBtn);

        const table = document.createElement('table');
        table.style.width = '100%';
        table.style.borderCollapse = 'collapse';
        modalContent.appendChild(table);

        const thead = document.createElement('thead');
        table.appendChild(thead);

        const headerRow = document.createElement('tr');
        thead.appendChild(headerRow);

        const thUrl = document.createElement('th');
        thUrl.textContent = 'URL';
        thUrl.style.border = '1px solid #ddd';
        thUrl.style.padding = '8px';
        thUrl.style.backgroundColor = '#f2f2f2';
        headerRow.appendChild(thUrl);

        const thDateTime = document.createElement('th');
        thDateTime.textContent = 'Data e Hora';
        thDateTime.style.border = '1px solid #ddd';
        thDateTime.style.padding = '8px';
        thDateTime.style.backgroundColor = '#f2f2f2';
        headerRow.appendChild(thDateTime);

        const thStatus = document.createElement('th');
        thStatus.textContent = 'Status';
        thStatus.style.border = '1px solid #ddd';
        thStatus.style.padding = '8px';
        thStatus.style.backgroundColor = '#f2f2f2';
        headerRow.appendChild(thStatus);

        const thActions = document.createElement('th');
        thActions.textContent = '';
        thActions.style.border = '1px solid #ddd';
        thActions.style.padding = '8px';
        thActions.style.backgroundColor = '#f2f2f2';
        headerRow.appendChild(thActions);

        const tbody = document.createElement('tbody');
        table.appendChild(tbody);

        function loadSchedules() {
            tbody.innerHTML = ''; // Clear the table body
            chrome.storage.local.get('schedules', (result) => {
                const schedules = result.schedules || [];
                schedules.forEach((schedule, index) => {
                    console.log('Schedule:', schedule);
                    const row = document.createElement('tr');
                    tbody.appendChild(row);

                    const cellUrl = document.createElement('td');
                    const urlLink = document.createElement('a');
                    urlLink.href = schedule.url;
                    urlLink.textContent = schedule.url;
                    cellUrl.appendChild(urlLink);
                    cellUrl.style.border = '1px solid #ddd';
                    cellUrl.style.padding = '8px';
                    row.appendChild(cellUrl);

                    const cellDateTime = document.createElement('td');
                    const date = new Date(schedule.dateTime);
                    const formattedDate = date.toLocaleString('pt-BR', {timeZone: 'America/Sao_Paulo'});
                    cellDateTime.textContent = formattedDate;
                    cellDateTime.style.border = '1px solid #ddd';
                    cellDateTime.style.padding = '8px';
                    row.appendChild(cellDateTime);

                    const cellStatus = document.createElement('td');
                    cellStatus.textContent = schedule.status;
                    cellStatus.style.border = '1px solid #ddd';
                    cellStatus.style.padding = '8px';
                    row.appendChild(cellStatus);

                    const cellActions = document.createElement('td');
                    cellActions.style.border = '1px solid #ddd';
                    cellActions.style.padding = '8px';
                    row.appendChild(cellActions);

                    const deleteBtn = document.createElement('button');
                    deleteBtn.textContent = 'Excluir';
                    deleteBtn.onclick = () => deleteSchedule(index);
                    cellActions.appendChild(deleteBtn);

                    const editBtn = document.createElement('button');
                    editBtn.textContent = 'Editar';
                    editBtn.onclick = () => editSchedule(index);
                    cellActions.appendChild(editBtn);

                    const toggleStatusBtn = document.createElement('button');
                    const buttonText = schedule.status.trim().normalize() === 'executando'.normalize() ? 'Parar' : 'Iniciar';
                    toggleStatusBtn.textContent = buttonText;
                    toggleStatusBtn.onclick = () => toggleStatus(index, toggleStatusBtn);
                    cellActions.appendChild(toggleStatusBtn);
                });
            });
        }

        loadSchedules();

        document.body.appendChild(modal);

        function deleteSchedule(index) {
            chrome.storage.local.get('schedules', (result) => {
                const schedules = result.schedules || [];
                schedules.splice(index, 1);
                chrome.storage.local.set({schedules: schedules}, () => {
                    loadSchedules();
                });
            });
        }

        function editSchedule(index) {
            chrome.storage.local.get('schedules', (result) => {
                const schedules = result.schedules || [];
                const schedule = schedules[index];
                const modal = createEditModal(schedule, index);
                document.body.appendChild(modal);
            });
        }

        function createEditModal(schedule, index) {
            const modal = document.createElement('div');
            modal.style.position = 'fixed';
            modal.style.zIndex = '1060';
            modal.style.left = '0';
            modal.style.top = '0';
            modal.style.width = '100%';
            modal.style.height = '100%';
            modal.style.overflow = 'auto';
            modal.style.backgroundColor = 'rgb(0,0,0)';
            modal.style.backgroundColor = 'rgba(0,0,0,0.4)';
            modal.style.paddingTop = '60px';

            const modalContent = document.createElement('div');
            modalContent.style.backgroundColor = '#fefefe';
            modalContent.style.margin = '5% auto';
            modalContent.style.padding = '20px';
            modalContent.style.border = '1px solid #888';
            modalContent.style.width = '300px';
            modalContent.style.boxShadow = '0 4px 8px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19)';
            modal.appendChild(modalContent);

            const closeBtn = document.createElement('span');
            closeBtn.innerHTML = '&times;';
            closeBtn.style.color = '#aaa';
            closeBtn.style.float = 'right';
            closeBtn.style.fontSize = '28px';
            closeBtn.style.fontWeight = 'bold';
            closeBtn.style.cursor = 'pointer';
            closeBtn.onclick = () => {
                modal.remove();
            };
            modalContent.appendChild(closeBtn);

            const modalTitle = document.createElement('h2');
            modalTitle.textContent = 'Editar Agendamento';
            modalContent.appendChild(modalTitle);

            const dateLabel = document.createElement('label');
            dateLabel.textContent = 'Data:';
            modalContent.appendChild(dateLabel);

            const dateInput = document.createElement('input');
            dateInput.type = 'date';
            dateInput.id = 'editScheduleDate';
            const date = new Date(schedule.dateTime);
            dateInput.value = date.toISOString().split('T')[0];
            dateInput.style.width = '100%';
            dateInput.style.marginBottom = '10px';
            modalContent.appendChild(dateInput);

            const timeLabel = document.createElement('label');
            timeLabel.textContent = 'Hora:';
            modalContent.appendChild(timeLabel);

            const timeInput = document.createElement('input');
            timeInput.type = 'time';
            timeInput.id = 'editScheduleTime';
            const time = date.toTimeString().split(' ')[0];
            timeInput.value = time;
            timeInput.style.width = '100%';
            timeInput.style.marginBottom = '10px';
            modalContent.appendChild(timeInput);

            const saveBtn = document.createElement('button');
            saveBtn.textContent = 'Salvar';
            saveBtn.style.width = '100%';
            saveBtn.onclick = () => saveEditedSchedule(index);
            modalContent.appendChild(saveBtn);

            return modal;
        }

        function saveEditedSchedule(index) {
            const date = document.getElementById('editScheduleDate').value;
            const time = document.getElementById('editScheduleTime').value;
            const scheduleDateTime = new Date(`${date}T${time}`);
            if (!isNaN(scheduleDateTime)) {
                chrome.storage.local.get('schedules', (result) => {
                    const schedules = result.schedules || [];
                    schedules[index].dateTime = scheduleDateTime.getTime();
                    schedules[index].status = 'Pendente';
                    chrome.storage.local.set({schedules: schedules}, () => {
                        alert('Agendamento editado com sucesso!');
                        loadSchedules();
                        document.querySelector('#editScheduleDate').parentElement.parentElement.remove();
                    });
                });
            } else {
                showAlert('Data/hora de agendamento inválida.', true);
            }
        }

        function toggleStatus(index, toggleStatusBtn) {
            console.log('Toggle status button clicked for index:', index);
            chrome.storage.local.get('schedules', (result) => {
                const schedules = result.schedules || [];
                if (schedules[index].status === 'executando') {
                    schedules[index].status = 'Parar';
                } else {
                    schedules[index].status = 'Iniciar';
                }
                chrome.storage.local.set({schedules: schedules}, () => {
                    loadSchedules();
                    console.log('Novo status:', schedules[index].status);
                    console.log('Texto do botão atualizado:', toggleStatusBtn.textContent);
                });
            });
        }
    }
});


function refreshSchedulesModalContent() {
    const updateButton = document.getElementById('refreshSchedulesButton');
    if (updateButton) {
        updateButton.click();
    }

}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    refreshSchedulesModalContent();
})


