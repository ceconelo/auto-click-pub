// Content script para injetar botão de agendamento no modal de histórico de previsão
// e salvar agendamentos no storage local

function injectButtons(modal) {
    if (modal) {
        const averbacaoButton = modal.querySelector('#priorizaAverbacao');
        if (averbacaoButton && !modal.querySelector('#scheduleButton')) {
              const scheduleButton = document.createElement('button');
              scheduleButton.textContent = "Agendar";
              scheduleButton.id = "scheduleButton";
              scheduleButton.style.marginLeft = '3px';

              averbacaoButton.parentNode.insertBefore(scheduleButton, averbacaoButton.nextSibling);

              scheduleButton.addEventListener('click', openScheduleModal);

              const scheduleModal = createScheduleModal();
              document.body.appendChild(scheduleModal);
        }
    }
}

function observeDOM() {
    const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
            if (mutation.type === 'childList' && mutation.addedNodes.length) {
                const modal = document.querySelector('#mdlHistoricoDaPrev'); // Modal que sera injeta o botao
                if (modal) {
                    injectButtons(modal);
                    observer.disconnect();
                }
            }
        });
    });

    observer.observe(document.body, {childList: true, subtree: true});
}

function createScheduleModal() {
    const modal = document.createElement('div');
    modal.id = 'scheduleModal';
    modal.style.display = 'none';
    modal.style.position = 'fixed';
    modal.style.zIndex = '1050'; // Maior que o modal existente
    modal.style.left = '0';
    modal.style.top = '0';
    modal.style.width = '100%';
    modal.style.height = '100%';
    modal.style.overflow = 'auto';
    modal.style.backgroundColor = 'rgb(0,0,0)';
    modal.style.backgroundColor = 'rgba(0,0,0,0.4)';
    modal.style.paddingTop = '60px';

    const modalContent = document.createElement('div');
    modalContent.style.backgroundColor = '#fefefe';
    modalContent.style.margin = '5% auto';
    modalContent.style.padding = '20px';
    modalContent.style.border = '1px solid #888';
    modalContent.style.width = '300px'; // Largura fixa ajustada
    modalContent.style.boxShadow = '0 4px 8px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19)';
    modal.appendChild(modalContent);

    const closeBtn = document.createElement('span');
    closeBtn.innerHTML = '&times;';
    closeBtn.style.color = '#aaa';
    closeBtn.style.float = 'right';
    closeBtn.style.fontSize = '28px';
    closeBtn.style.fontWeight = 'bold';
    closeBtn.style.cursor = 'pointer';
    closeBtn.onclick = () => {
        modal.style.display = 'none';
    };
    modalContent.appendChild(closeBtn);

    const modalTitle = document.createElement('h2');
    modalTitle.textContent = 'Agendar';
    modalContent.appendChild(modalTitle);

    const dateLabel = document.createElement('label');
    dateLabel.textContent = 'Data:';
    modalContent.appendChild(dateLabel);

    const dateInput = document.createElement('input');
    dateInput.type = 'date';
    dateInput.id = 'scheduleDate';
    dateInput.style.width = '100%'; // Largura 100% para inputs
    dateInput.style.marginBottom = '10px';
    modalContent.appendChild(dateInput);

    const timeLabel = document.createElement('label');
    timeLabel.textContent = 'Hora:';
    modalContent.appendChild(timeLabel);

    const timeInput = document.createElement('input');
    timeInput.type = 'time';
    timeInput.id = 'scheduleTime';
    timeInput.style.width = '100%'; // Largura 100% para inputs
    timeInput.style.marginBottom = '10px';
    modalContent.appendChild(timeInput);

    const saveBtn = document.createElement('button');
    saveBtn.textContent = 'Salvar Agendamento';
    saveBtn.style.width = '100%'; // Largura 100% para botão
    saveBtn.onclick = saveSchedule;
    modalContent.appendChild(saveBtn);

    return modal;
}

function openScheduleModal() {
    const modal = document.getElementById('scheduleModal');
    modal.style.display = 'block';
}

function saveSchedule() {
    const scheduleDate = document.getElementById('scheduleDate').value;
    const scheduleTime = document.getElementById('scheduleTime').value;
    const scheduleDateTime = new Date(`${scheduleDate}T${scheduleTime}`);
    if (!isNaN(scheduleDateTime)) {
        chrome.storage.local.get('schedules', (result) => {
            const schedules = result.schedules || [];
            schedules.push({url: window.location.href, dateTime: scheduleDateTime.getTime(), status: 'Pendente'});
            chrome.storage.local.set({schedules: schedules}, () => {
                alert('Agendamento salvo com sucesso!');
                const modal = document.getElementById('scheduleModal');
                modal.style.display = 'none';
            });
        });
    } else {
        alert('Data/hora de agendamento inválida.');
    }
}

observeDOM();
