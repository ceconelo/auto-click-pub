let checkInterval = 15000;
let checkIntervals = {};
let loginCheckInterval = null
let intervalTime = null


chrome.runtime.onInstalled.addListener(() => {
    startLoginCheck();
});

chrome.runtime.onStartup.addListener(() => {
    startLoginCheck();
});

chrome.windows.onRemoved.addListener((tabId, removeInfo) => {
    stopAllChecks();
});

function stopAllChecks() {
    chrome.storage.local.get('schedules', (result) => {
        const schedules = result.schedules || [];
        schedules.forEach((schedule, index) => {
            if (schedule.status === 'executando') {
                schedules[index].status = 'Parado';
            }
        });
        chrome.storage.local.set({schedules: schedules}, () => {
            Object.keys(checkIntervals).forEach(index => {
                clearInterval(checkIntervals[index]);
                delete checkIntervals[index];
            });
        });
    });
}

function startLoginCheck() {
    loginCheckInterval = setInterval(() => {
        checkLoginStatus().then(isLoggedIn => {
            if (isLoggedIn) {
                clearInterval(loginCheckInterval);
                loginCheckInterval = null;
                startScheduleCheck();
            }
        });
    }, 1000);
}

function startScheduleCheck() {
    chrome.storage.local.get('interval', (data) => {
        checkInterval = data.interval || 15000;
    });
    setInterval(() => {
        checkSchedule();
    }, 1000);
}

function startRequestData(url, scheduleIndex) {
    ajaxPrioriozaAverbacao(url, scheduleIndex);

    checkIntervals[scheduleIndex] = setInterval(() => {
        ajaxPrioriozaAverbacao(url, scheduleIndex);
        //buscaHistoricoDataprev(url, scheduleIndex);
    }, checkInterval);
}

function stopRequestData(index) {
    clearInterval(checkIntervals[index]);
    delete checkIntervals[index];
}

function checkSchedule() {
    console.log('Verificando agendamentos');
    chrome.storage.local.get('schedules', (result) => {
        const schedules = result.schedules || [];
        const now = new Date().getTime();

        schedules.forEach((schedule, index) => {
            if (schedule.status === 'Parar') {
                schedules[index].status = 'Parado';
                chrome.storage.local.set({schedules: schedules});
                stopRequestData(index);
                refreshModalSchedulesContent()
            }

            if (schedule.status === 'Iniciar') {
                schedules[index].status = 'executando';
                chrome.storage.local.set({schedules: schedules});
                startRequestData(schedule.url, index);
                refreshModalSchedulesContent()
            }

            const timeUntilScheduled = schedule.dateTime - now;
            if (timeUntilScheduled >= 0 && timeUntilScheduled <= 60000 && (schedule.status === 'Pendente')) {
                schedules[index].status = 'executando';
                chrome.storage.local.set({schedules: schedules})
                startRequestData(schedule.url, index);
                refreshModalSchedulesContent()
            }
        });
    });
}

function buscaHistoricoDataprev(url, scheduleIndex) {
    const codigoMatch = url.match(/[?&]codigo=([^&]+)/);
    const codigo_af = codigoMatch ? codigoMatch[1] : null;

    if (!codigo_af) {
        console.error('Código não encontrado na URL.');
        return;
    }

    console.log('Requesting buscaHistoricoDataprev:', codigo_af);
    chrome.storage.local.get('sessionCookie', async (result) => {
        const sessionCookie = result.sessionCookie;

        try {
            const response = await fetch('https://desenv.facta.com.br/sistemaNovo/ajax/propostas/busca_historico_dataprev.php', {
                method: 'POST',
                headers: {
                    'authority': 'desenv.facta.com.br',
                    'accept': 'text/html, */*; q=0.01',
                    'accept-language': 'en-US,en;q=0.9',
                    'cache-control': 'no-cache',
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'cookie': sessionCookie,
                    'origin': 'https://desenv.facta.com.br',
                    'pragma': 'no-cache',
                    'referer': url,
                    'sec-ch-ua': '"Google Chrome";v="119", "Chromium";v="119", "Not?A_Brand";v="24"',
                    'sec-ch-ua-mobile': '?0',
                    'sec-ch-ua-platform': '"Linux"',
                    'sec-fetch-dest': 'empty',
                    'sec-fetch-mode': 'cors',
                    'sec-fetch-site': 'same-origin',
                    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, como Gecko) Chrome/119.0.0.0 Safari/537.36',
                    'x-requested-with': 'XMLHttpRequest'
                },
                body: new URLSearchParams({
                    'codigo_af': codigo_af
                })
            });

            const result = await response.text();
            const rows = parseTableHtml(result);
            const lastRow = rows[0];
            const returnDataPrev = lastRow.retornoDataPrev;

            const phrasesToCheck = [
                'IF - BENEFICIO BLOQUEADO NA CONCESSAO',
                'FH - OPERAÇÃO FORA DO HORÁRIO PERMITIDO',
                'Não existem dados ainda.',
                'Erro de comunicação com a DATAPREV'
            ];

            if (!phrasesToCheck.includes(returnDataPrev)) {
                console.log('A mensagem mudou:', returnDataPrev);
                chrome.storage.local.get('schedules', (result) => {
                    const schedules = result.schedules || [];
                    schedules[scheduleIndex].status = 'A mensagem mudou!';
                    chrome.storage.local.set({schedules: schedules});
                    stopRequestData(scheduleIndex);
                    refreshModalSchedulesContent()
                });
            }
        } catch (error) {
            console.error('Erro ao realizar a requisição:', error);
        }
    });
}

function ajaxPrioriozaAverbacao(url, scheduleIndex) {
    const codigoMatch = url.match(/[?&]codigo=([^&]+)/);
    const codigo_af = codigoMatch ? codigoMatch[1] : null;

    if (!codigo_af) {
        console.error('Código não encontrado na URL.');
        return;
    }

    console.log('Requesting ajaxPriorizaAverbacao:', codigo_af);
    chrome.storage.local.get('sessionCookie', async (result) => {
        const sessionCookie = result.sessionCookie;

        try {
            const response = await fetch('https://desenv.facta.com.br/sistemaNovo/ajax/ajax_prioriza_averbacao.php', {
                method: 'POST',
                headers: {
                    'authority': 'desenv.facta.com.br',
                    'accept': 'text/html, */*; q=0.01',
                    'accept-language': 'en-US,en;q=0.9',
                    'cache-control': 'no-cache',
                    'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    'cookie': sessionCookie,
                    'origin': 'https://desenv.facta.com.br',
                    'pragma': 'no-cache',
                    'referer': url,
                    'sec-ch-ua': '"Google Chrome";v="119", "Chromium";v="119", "Not?A_Brand";v="24"',
                    'sec-ch-ua-mobile': '?0',
                    'sec-ch-ua-platform': '"Linux"',
                    'sec-fetch-dest': 'empty',
                    'sec-fetch-mode': 'cors',
                    'sec-fetch-site': 'same-origin',
                    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, como Gecko) Chrome/119.0.0.0 Safari/537.36',
                    'x-requested-with': 'XMLHttpRequest'
                },
                body: new URLSearchParams({
                    'codigoaf': codigo_af
                })
            });

            const result = await response.text();
            console.log('Resultado:', result);

            const phrasesToCheck = [
                'IF - BENEFICIO BLOQUEADO NA CONCESSAO',
                'FH - OPERAÇÃO FORA DO HORÁRIO PERMITIDO',
                'Não existem dados ainda.',
                'Erro de comunicação com a DATAPREV'
            ];

            const resultNormalized = normalizeString(result)
            const containsResult = containsSignificantPhrase(resultNormalized, phrasesToCheck);

            if (!containsResult) {
                console.log('A mensagem mudou:', result);
                chrome.storage.local.get('schedules', (result) => {
                    const schedules = result.schedules || [];
                    schedules[scheduleIndex].status = 'A mensagem mudou!';
                    chrome.storage.local.set({schedules: schedules});
                    stopRequestData(scheduleIndex);
                    refreshModalSchedulesContent()
                });
            }

        } catch (error) {
            console.error('Erro ao realizar a AjaxPriorizaAverbacao:', error);
        }
    });
}

function parseTableHtml(htmlString) {
    const noDataMessageRegex = /<td[^>]*>\s*Não existem dados ainda.\s*<\/td>/i;
    const rowRegex = /<tr>\s*<td[^>]*>(.*?)<\/td>\s*<td[^>]*>(.*?)<\/td>\s*<td[^>]*>(.*?)<\/td>\s*<td[^>]*>(.*?)<\/td>\s*<td[^>]*>(.*?)<\/td>\s*<\/tr>/g;

    if (noDataMessageRegex.test(htmlString)) {
        return [{retornoDataPrev: 'Não existem dados ainda.'}];
    }

    const rows = [];
    let match;
    while ((match = rowRegex.exec(htmlString)) !== null) {
        console.log('Match:', match);
        rows.push({
            data: match[1].trim(),
            retornoDataPrev: match[2].trim(),
            valorOperacao: match[3].trim(),
            valorPmt: match[4].trim(),
            primeiroVencimento: match[5].trim()
        });
    }
    return rows;
}

function normalizeString(str) {
    return str.normalize('NFD').replace(/[\u0300-\u036f]/g, "").toLowerCase();
}

function getSignificantWords(phrase) {
    const insignificantWords = ['de', 'do', 'da', 'a', 'e', 'o', 'para', 'na', 'no'];
    return phrase.split(/\s+/).filter(word => !insignificantWords.includes(word));
}

function containsSignificantPhrase(resultNormalized, phrasesToCheck) {
    return phrasesToCheck.some(phrase => {
        const normalizedPhrase = normalizeString(phrase);
        const significantWords = getSignificantWords(normalizedPhrase);
        return significantWords.some(word => resultNormalized.includes(word));
    });
}

async function checkLoginStatus() {
    try {
        const response = await fetch('https://desenv.facta.com.br/sistemaNovo/dashboard.php', {
            method: 'GET'
        });

        if (response.redirected && response.url.includes('https://desenv.facta.com.br/sistemaNovo/login.php')) {
            console.log('Usuário não logado');
            return false;
        }
        console.log('Usuário logado');
        return true;
    } catch (error) {
        console.error('Erro ao verificar status de login:', error);
        return false;
    }
}

function refreshModalSchedulesContent() {
    chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
        const activeTab = tabs[0]
        chrome.tabs.sendMessage(activeTab.id, {message: 'refreshModalSchedulesContent'});
    });
}
